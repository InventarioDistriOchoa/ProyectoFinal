<?php
// backend_php/api/listarID.php

include "../config/conexion.php";

header("Access-Control-Allow-Methods: GET");

// Obtener ID del parámetro de la URL
if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "mensaje" => "Falta el parámetro 'id' en la URL."
    ]);
    exit();
}

$idEntrada = (int)$_GET['id'];

$sql = "SELECT idEntrada, fecha, cantidad FROM entradas WHERE idEntrada = $idEntrada LIMIT 1";
$resultado = $conexion->query($sql);

if ($resultado && $resultado->num_rows > 0) {
    $entrada = $resultado->fetch_assoc();
    // Aseguramos tipos enteros
    $entrada['idEntrada'] = (int)$entrada['idEntrada'];
    $entrada['cantidad'] = (int)$entrada['cantidad'];

    http_response_code(200);
    echo json_encode([
        "status" => "ok",
        "data" => $entrada
    ]);
} else {
    http_response_code(404); // Not Found
    echo json_encode([
        "status" => "error",
        "mensaje" => "Entrada con ID $idEntrada no encontrada."
    ]);
}

$conexion->close();
?>