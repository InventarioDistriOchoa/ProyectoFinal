<?php
// backend_php/api/listarEntradas.php

include "../config/conexion.php";

header("Access-Control-Allow-Methods: GET");

$sql = "SELECT idEntrada, fecha, cantidad FROM entradas ORDER BY fecha DESC";
$resultado = $conexion->query($sql);

$entradas = array();

if ($resultado) {
    while ($row = $resultado->fetch_assoc()) {
        // Aseguramos que los números sean enteros
        $row['idEntrada'] = (int)$row['idEntrada'];
        $row['cantidad'] = (int)$row['cantidad'];
        $entradas[] = $row;
    }

    echo json_encode([
        "status" => "ok", // Estructura de respuesta tipo listarUsuarios
        "data" => $entradas // Devolvemos la lista en el campo "data"
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "mensaje" => "Error en la consulta SQL para listar."
    ]);
}

$conexion->close();
?>