<?php
// backend_php/api/actualizar.php

include "../config/conexion.php";

header("Access-Control-Allow-Methods: PUT");

$input = file_get_contents("php://input");
$data = json_decode($input, true);

if (!$data || !isset($data['idEntrada']) || !isset($data['fecha']) || !isset($data['cantidad'])) {
    http_response_code(400); 
    echo json_encode([
        "status" => "error",
        "mensaje" => "Datos incompletos para actualizar (ID, fecha o cantidad)."
    ]);
    exit();
}

$idEntrada = (int)$data['idEntrada'];
$fecha = $conexion->real_escape_string($data['fecha']);
$cantidad = (int)$data['cantidad'];

$sql = "UPDATE entradas SET fecha='$fecha', cantidad=$cantidad WHERE idEntrada=$idEntrada";
$resultado = $conexion->query($sql);

if ($resultado && $conexion->affected_rows > 0) {
    http_response_code(200);
    echo json_encode([
        "status" => "ok",
        "mensaje" => "Entrada actualizada con éxito"
    ]);
} else if ($resultado && $conexion->affected_rows === 0) {
    http_response_code(404);
    echo json_encode([
        "status" => "error",
        "mensaje" => "No se encontró la entrada con ID $idEntrada para actualizar."
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "mensaje" => "Error al actualizar la entrada: " . $conexion->error
    ]);
}

$conexion->close();
?>