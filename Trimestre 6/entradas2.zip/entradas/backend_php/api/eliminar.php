<?php
// backend_php/api/eliminar.php

include "../config/conexion.php";

header("Access-Control-Allow-Methods: DELETE");

$input = file_get_contents("php://input");
$data = json_decode($input, true);

if (!$data || !isset($data['idEntrada'])) {
    http_response_code(400); 
    echo json_encode([
        "status" => "error",
        "mensaje" => "Falta el ID para eliminar."
    ]);
    exit();
}

$idEntrada = (int)$data['idEntrada'];

$sql = "DELETE FROM entradas WHERE idEntrada=$idEntrada";
$resultado = $conexion->query($sql);

if ($resultado && $conexion->affected_rows > 0) {
    http_response_code(200);
    echo json_encode([
        "status" => "ok",
        "mensaje" => "Entrada eliminada con éxito"
    ]);
} else if ($resultado && $conexion->affected_rows === 0) {
    http_response_code(404);
     echo json_encode([
        "status" => "error",
        "mensaje" => "No se encontró la entrada para eliminar."
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "mensaje" => "Error al intentar eliminar: " . $conexion->error
    ]);
}

$conexion->close();
?>