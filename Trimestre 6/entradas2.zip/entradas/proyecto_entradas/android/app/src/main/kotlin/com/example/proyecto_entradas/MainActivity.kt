package com.example.proyecto_entradas

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
