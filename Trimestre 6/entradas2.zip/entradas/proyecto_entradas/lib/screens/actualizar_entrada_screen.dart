import 'package:flutter/material.dart';
import '../models/entrada.dart';
import '../services/api_service.dart';

class ActualizarEntradaScreen extends StatefulWidget {
  final Entrada entrada;

  const ActualizarEntradaScreen({super.key, required this.entrada});

  @override
  State<ActualizarEntradaScreen> createState() => _ActualizarEntradaScreenState();
}

class _ActualizarEntradaScreenState extends State<ActualizarEntradaScreen> {
  late TextEditingController _cantidadController;
  DateTime? _fechaSeleccionada;

  @override
  void initState() {
    super.initState();
    _cantidadController =
        TextEditingController(text: widget.entrada.cantidad.toString());
    _fechaSeleccionada = widget.entrada.fecha;
  }

 Future<void> _actualizar() async {
  Entrada actualizada = Entrada(
    idEntrada: widget.entrada.idEntrada,
    fecha: _fechaSeleccionada!,
    cantidad: int.parse(_cantidadController.text),
  );

  // ✅ Método static
  bool ok = await ApiService.actualizarEntrada(actualizada);

  if (ok) {
    Navigator.pop(context, true);
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Error al actualizar")),
    );
  }
}
  Future<void> _seleccionarFecha() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _fechaSeleccionada ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (picked != null) {
      setState(() {
        _fechaSeleccionada = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Actualizar Entrada")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: _seleccionarFecha,
              child: Text("Fecha: ${_fechaSeleccionada!.toString().split(' ')[0]}"),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _cantidadController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: "Cantidad"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _actualizar,
              child: const Text("Guardar Cambios"),
            ),
          ],
        ),
      ),
    );
  }
}