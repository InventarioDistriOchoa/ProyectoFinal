import 'package:flutter/material.dart';
import '../models/entrada.dart';
import '../services/api_service.dart';

class FormularioEntradaScreen extends StatefulWidget {
  final Entrada? entrada;

  const FormularioEntradaScreen({Key? key, this.entrada}) : super(key: key);

  @override
  _FormularioEntradaScreenState createState() => _FormularioEntradaScreenState();
}

class _FormularioEntradaScreenState extends State<FormularioEntradaScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _cantidadController = TextEditingController();
  DateTime _selectedDate = DateTime.now();

  bool get isEditing => widget.entrada != null;

  @override
  void initState() {
    super.initState();
    if (isEditing) {
      _cantidadController.text = widget.entrada!.cantidad.toString();
      _selectedDate = widget.entrada!.fecha;
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      setState(() => _selectedDate = picked);
    }
  }

  Future<void> _submitForm() async {
    if (_formKey.currentState!.validate()) {
      final entradaData = Entrada(
        idEntrada: isEditing ? widget.entrada!.idEntrada : null,
        fecha: _selectedDate,
        cantidad: int.parse(_cantidadController.text),
      );

      bool success;
      String message;

      if (isEditing) {
        success = await ApiService.actualizarEntrada(entradaData);
        message = success ? 'Entrada actualizada con éxito.' : 'Error al actualizar.';
      } else {
        success = await ApiService.insertarEntrada(entradaData);
        message = success ? 'Entrada creada con éxito.' : 'Error al crear.';
      }

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      if (success) {
        Navigator.pop(context, true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(isEditing ? 'Editar Entrada' : 'Nueva Entrada')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: _cantidadController,
                decoration: InputDecoration(labelText: 'Cantidad'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || int.tryParse(value) == null) {
                    return 'Ingrese un número entero válido';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  Text("Fecha: ${_selectedDate.toIso8601String().split('T').first}"),
                  SizedBox(width: 20),
                  ElevatedButton(
                    onPressed: () => _selectDate(context),
                    child: Text('Seleccionar Fecha'),
                  ),
                ],
              ),
              SizedBox(height: 40),
              Center(
                child: ElevatedButton(
                  onPressed: _submitForm,
                  child: Text(isEditing ? 'Guardar Cambios' : 'Registrar Entrada'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
