// proyecto_entradas/lib/lista_entradas_screen.dart
import 'package:flutter/material.dart'; // Importación simplificada
import 'formulario_entrada_screen.dart';
import '../models/entrada.dart';
import '../services/api_service.dart';

 // Importación simplificada

// Pantalla para listar, actualizar y eliminar entradas
class ListaEntradasScreen extends StatefulWidget {
  const ListaEntradasScreen({super.key});
   
  @override
  State<ListaEntradasScreen>createState() => 
  _ListaEntradasScreenState();
}

class _ListaEntradasScreenState extends State<ListaEntradasScreen> {
  late Future<List<Entrada>> futureEntradas;
  final ApiService apiService = ApiService();

  @override
  void initState() {
    super.initState();
    _fetchEntradas();
  }

  void _fetchEntradas() {
    setState(() {
      futureEntradas = apiService.listarEntradas();
    });
  }
// Navegar a la pantalla de formulario y recargar la lista al regresar
  void _navigateAndReload(Entrada? entradaToEdit) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FormularioEntradaScreen(entrada: entradaToEdit),
      ),
    );
    if (result == true) {
      _fetchEntradas(); // Recargar la lista
    }
  }

  void _eliminarEntrada(int id) async {
    bool success = await apiService.eliminarEntrada(id);
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Entrada eliminada.')));
      _fetchEntradas();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error al eliminar.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Registro de Entradas (CRUD)')),
      body: FutureBuilder<List<Entrada>>(
        future: futureEntradas,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No hay entradas registradas.'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                Entrada entrada = snapshot.data![index];
                return ListTile(
                  title: Text('ID ${entrada.idEntrada} - Cantidad: ${entrada.cantidad}'),
                  subtitle: Text('Fecha: ${entrada.fecha.toString().split(' ')[0]}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _navigateAndReload(entrada), 
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _eliminarEntrada(entrada.idEntrada!),
                      ),
                    ],
                  ),
                );
              },
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _navigateAndReload(null),
        child: Icon(Icons.add),
      ),
    );
  }
}