import 'package:flutter/material.dart';
import '../services/api_service.dart';

class EliminarEntradaScreen extends StatefulWidget {
  const EliminarEntradaScreen({super.key});

  @override
  State<EliminarEntradaScreen> createState() => _EliminarEntradaScreenState();
}

class _EliminarEntradaScreenState extends State<EliminarEntradaScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _idController = TextEditingController();

  Future<void> _eliminarEntrada() async {
    if (!_formKey.currentState!.validate()) return;

    int id = int.parse(_idController.text);

    bool ok = await ApiService.eliminarEntrada(id);

    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Entrada eliminada correctamente")),
      );
      _idController.clear();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Error al eliminar la entrada")),
      );
    }
  }

  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Eliminar Entrada"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _idController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "ID de Entrada",
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Ingresa el ID";
                  }
                  if (int.tryParse(value) == null) {
                    return "Debe ser un número";
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _eliminarEntrada,
                child: const Text("Eliminar"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}