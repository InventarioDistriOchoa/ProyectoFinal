import 'package:flutter/material.dart';
import '../models/entrada.dart';
import '../services/api_service.dart';
import 'formulario_entrada_screen.dart';
import 'actualizar_entrada_screen.dart';

class InsertarEntradaScreen extends StatefulWidget {
  const InsertarEntradaScreen({super.key});

  @override
  State<InsertarEntradaScreen> createState() => _InsertarEntradaScreenState();
}

class _InsertarEntradaScreenState extends State<InsertarEntradaScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _cantidadController = TextEditingController();

  DateTime? _fechaSeleccionada;

  Future<void> _seleccionarFecha() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (picked != null) {
      setState(() {
        _fechaSeleccionada = picked;
      });
    }
  }

// Insertar nueva entrada
  Future<void> _() async {
    if (!_formKey.currentState!.validate() || _fechaSeleccionada == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Completa todos los campos")),
      );
      return;
    }

    Entrada nueva = Entrada(
      fecha: _fechaSeleccionada!,
      cantidad: int.parse(_cantidadController.text),
    );

    bool ok = await ApiService().insertarEntrada(nueva);

    if (ok) {
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Error al insertar")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Insertar Entrada")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              ElevatedButton(
                onPressed: _seleccionarFecha,
                child: Text(_fechaSeleccionada == null
                    ? "Seleccionar Fecha"
                    : "Fecha: ${_fechaSeleccionada!.toString().split(' ')[0]}"),
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _cantidadController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Cantidad"),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Ingresa la cantidad";
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _insertar,
                child: const Text("Guardar"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}