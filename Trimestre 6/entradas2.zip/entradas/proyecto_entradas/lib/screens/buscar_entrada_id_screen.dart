import 'package:flutter/material.dart';
import '../models/entrada.dart';
import '../services/api_service.dart';
import 'actualizar_entrada_screen.dart';

class BuscarEntradaIDScreen extends StatefulWidget {
  
  final bool modoActualizar;

  const BuscarEntradaIDScreen({super.key, required this.modoActualizar});

  @override
  State<BuscarEntradaIDScreen> createState() =>
   _BuscarEntradaIDScreenState();
}

class _BuscarEntradaIDScreenState extends State<BuscarEntradaIDScreen> {
  final TextEditingController _idController = TextEditingController();
  Entrada? entrada;

  Future<void> _buscar() async {
    final id = int.tryParse(_idController.text);

    if (id == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("ID inválido")),
      );
      return;
    }

    final result = await ApiService().BuscarEntradaPorId(id);

    if (result == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No encontrada")),
      );
    }

    setState(() => entrada = result);

    if (widget.modoActualizar && result != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ActualizarEntradaScreen(entrada: result),
        ),
      );
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Buscar Entrada por ID")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _idController,
              decoration: const InputDecoration(labelText: "ID"),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _buscar,
              child: const Text("Buscar"),
            ),
            const SizedBox(height: 20),
            if (entrada != null) ...[
              Text("ID: ${entrada!.idEntrada}"),
              Text("Cantidad: ${entrada!.cantidad}"),
              Text("Fecha: ${entrada!.fecha.toString().split(' ')[0]}"),
            ]
          ],
        ),
      ),
    );
  }
}