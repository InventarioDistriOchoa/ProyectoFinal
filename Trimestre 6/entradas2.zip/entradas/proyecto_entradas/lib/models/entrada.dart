class Entrada {
  final int? idEntrada;
  final DateTime fecha;
  final int cantidad;

  Entrada({this.idEntrada, required this.fecha, required this.cantidad});

  factory Entrada.fromJson(Map<String, dynamic> json) {
    return Entrada(
      idEntrada: json["id_entrada"],
      fecha: DateTime.parse(json["fecha"]),
      cantidad: int.parse(json["cantidad"].toString()),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "idEntrada": idEntrada,
      "fecha": fecha.toIso8601String().split("T")[0],
      "cantidad": cantidad,
    };
  }
}
