import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/entrada.dart';

class ApiService {
  static const String baseUrl = "http://localhost/ENTRADAS/backend_php/api/";

  

  // GET: Obtener todas las entradas
  static Future<List<Entrada>> getEntradas() async {
    final response = await http.get(Uri.parse("$baseUrl/listar_entradas.php"));

    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((e) => Entrada.fromJson(e)).toList();
    } else {
      throw Exception("Error al obtener entradas");
    }
  }

  // POST: Crear nueva entrada
  static Future<bool> insertarEntrada(Entrada entrada) async {
    final response = await http.post(
      Uri.parse("$baseUrl/insertar_entrada.php"),
      body: entrada.toJson(),
    );

    return response.statusCode == 200;
  }

  // PUT/POST: Actualizar entrada
  static Future<bool> actualizarEntrada(Entrada entrada) async {
    final response = await http.post(
      Uri.parse("$baseUrl/actualizar_entrada.php"),
      body: entrada.toJson(),
    );

    return response.statusCode == 200;
  }

  // DELETE: Eliminar entrada
  static Future<bool> eliminarEntrada(int id) async {
    final response = await http.post(
      Uri.parse("$baseUrl/eliminar_entrada.php"),
      body: {"id_entrada": id.toString()},
    );

    return response.statusCode == 200;
  }

  // GET: Buscar entrada por ID
  static Future<Entrada?> BuscarEntradaPorId(int id) async {
    final response = await http.get(
      Uri.parse("$baseUrl/buscar_entrada.php?id_entrada=$id"),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data != null) {
        return Entrada.fromJson(data);
      }
    }
    return null;
  }
}