import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const String baseUrl = 
    'http://10.0.2.2:8080/NUEVO_PROYECTO/Backend/Endpoints/agregar_usuario.php';

class RegistroScreen extends StatefulWidget {
  const RegistroScreen({super.key});

  @override
  State<RegistroScreen> createState() => _RegistroScreenState();
}

class _RegistroScreenState extends State<RegistroScreen> {
  final _formKey = GlobalKey<FormState>();
  
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _claveController = TextEditingController();


  String _mensajeEstado = '';

  @override
  void dispose() {
    _nombreController.dispose();
    _emailController.dispose();
    _claveController.dispose();
    super.dispose();
  }
// --- Función de Registro (igual a la anterior, pero actualiza el estado) ---
  Future<void> _registrarUsuario() async {
    if (!_formKey.currentState!.validate()) {
      return; // No hacer nada si el formulario no es válido
    }

    setState(() {
      _mensajeEstado = 'Registrando usuario...';
    });
    
    // Obtener los valores de los controladores
    final nombre = _nombreController.text;
    final email = _emailController.text;
    final clave = _claveController.text;

    Map<String, dynamic> body = {
      'nombre': nombre,
      'email': email,
      'clave': clave,
    };

    try {
      final response = await http.post(
        Uri.parse(baseUrl),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(body),
      );

      final responseData = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (responseData['success'] == true) {
           setState(() {
            _mensajeEstado = '✅ Éxito: Usuario ID ${responseData['id']} creado.';
          });
        } else {
          // Error lógico (ej. email duplicado)
          setState(() {
            _mensajeEstado = '❌ Error: ${responseData['message']}';
          });
        }
      } else {
        // Error HTTP (500, 404, etc.)
        setState(() {
          _mensajeEstado = '🔥 Error de Servidor: Código ${response.statusCode}';
        });
      }
    } catch (e) {
      // Error de red
      setState(() {
        _mensajeEstado = '🚨 Error de Conexión: $e';
      });
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Registro de Usuario (PHP/Flutter)'),
        backgroundColor: Colors.blueGrey,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              // --- Campo Nombre ---
              TextFormField(
                controller: _nombreController,
                decoration: const InputDecoration(labelText: 'Nombre Completo'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor, ingresa tu nombre.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 15),

              // --- Campo Email ---
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(labelText: 'Correo Electrónico'),
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value == null || !value.contains('@')) {
                    return 'Ingresa un correo electrónico válido.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 15),

              // --- Campo Clave (Contraseña) ---
              TextFormField(
                controller: _claveController,
                decoration: const InputDecoration(labelText: 'Contraseña'),
                obscureText: true, // Ocultar el texto
                validator: (value) {
                  if (value == null || value.length < 6) {
                    return 'La contraseña debe tener al menos 6 caracteres.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 30),

              // --- Botón de Registro ---
              ElevatedButton(
                onPressed: _registrarUsuario,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                ),
                child: const Text('Registrar Usuario', style: TextStyle(fontSize: 18)),
              ),
              
              const SizedBox(height: 20),
              
              // --- Mostrar Mensaje de Estado ---
              Center(
                child: Text(
                  _mensajeEstado,
                  style: TextStyle(
                    color: _mensajeEstado.startsWith('✅') ? Colors.green : 
                           _mensajeEstado.startsWith('❌') ? Colors.red : Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}