import 'package:flutter/material.dart';
import 'package:flutterproyecto/screens/registro_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'App de Registro',
      debugShowCheckedModeBanner: false,
      home: const RegistroScreen(),
    );
  }
}