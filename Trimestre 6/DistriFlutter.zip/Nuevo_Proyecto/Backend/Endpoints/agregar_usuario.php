<?php
// Establece el encabezado para indicar que la respuesta será JSON
header('Content-Type: application/json');

// Permitir solicitudes de cualquier origen (CORS) - solo para desarrollo
// En producción, esto debe ser restringido
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// --- 1. CONFIGURACIÓN DE LA BASE DE DATOS ---
$host = 'localhost';
$db   = 'proyecto_flutter';
$user = 'root'; // Cambia esto por tu usuario de MySQL
$pass = 'sena';     // Cambia esto por tu contraseña de MySQL
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

// --- 2. RECUPERAR DATOS DE LA SOLICITUD ---
// El endpoint POST recibe los datos en formato JSON a través del cuerpo (body) de la solicitud.
$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

// Verificar si se recibieron los datos esperados
if (!isset($data['nombre'], $data['email'], $data['clave'])) {
    echo json_encode(['success' => false, 'message' => 'Faltan datos requeridos (nombre, email, clave).']);
    exit();
}

$nombre = $data['nombre'];
$email = $data['email'];
$clave_plana = $data['clave'];

// --- 3. PROCESAR Y ALMACENAR DATOS ---
try {
    // Conexión
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Hash de la clave (¡CRUCIAL para seguridad!)
    $clave_hashed = password_hash($clave_plana, PASSWORD_DEFAULT);

    // Consulta SQL para insertar
    $sql = "INSERT INTO usuarios (nombre, email, clave) VALUES (?, ?, ?)";
    
    // Preparar y ejecutar la consulta (usa consultas preparadas para evitar inyección SQL)
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nombre, $email, $clave_hashed]);

    // Respuesta exitosa
    echo json_encode([
        'success' => true, 
        'message' => 'Usuario agregado exitosamente.', 
        'id' => $pdo->lastInsertId()
    ]);

} catch (\PDOException $e) {
    // Manejo de errores (ej. email duplicado)
    $error_message = $e->getMessage();
    
    // Si es un error de clave duplicada (ej. email UNIQUE)
    if (strpos($error_message, 'Duplicate entry') !== false) {
        $response = ['success' => false, 'message' => 'Error: El email ya está registrado.'];
    } else {
        $response = ['success' => false, 'message' => 'Error al agregar el usuario: ' . $error_message];
    }
    
    // Devuelve el error como JSON
    http_response_code(500); // Código de error del servidor
    echo json_encode($response);
}

?>