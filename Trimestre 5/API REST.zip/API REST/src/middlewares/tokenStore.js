// tokenStore.js
export const activeTokens = new Map();

export const TOKEN_EXPIRATION = 20 * 60 * 1000; // 20 minutos
